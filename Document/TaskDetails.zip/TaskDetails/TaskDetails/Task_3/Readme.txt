Step 1 > Setup the enviornment first every time.
E:\ESP_IDF\GitHubrRepo\ESPC6_Project>sdk_setup.bat

Step 2 > Use command to create main
E:\ESP_IDF\GitHubrRepo\ESPC6_Project>idf.py create-project main

Executing action: create-project
The project was created in E:\ESP_IDF\ESPC6_Project\main

Note-: 
1.here two main will be created, So need to delete one main folder.
2.Change the Project name as per your project name (ESPC6_Project) in the Outer CMakeLists.txt


Step 3 > set the target as esp32c6
E:\ESP_IDF\GitHubrRepo\ESPC6_Project>idf.py set-target esp32c6

Note-: 
1. First time build & sdkconfig file will be created.
2. Target will be set for esp32c6 in sdkconfig.

Step 5 > Now it is ready for build the code .
E:\ESP_IDF\ESP_Project>idf.py build

Note-: 
1. Binary file will be created in the build folder for esp32-c6.

Step 6 > now binary is ready to load into board.
Command: idf.py -p (PORT) flash
Example: idf.py -p COM50 flash
step1
------
- Clone the blank Repo from the github & go into the project
cd ESPS3_Project/

step2
------
- Adding a Git submodule with a specific branch.
git submodule add -b release/v5.1 https://github.com/espressif/esp-idf.git esp_idf

step3
------
- Checkout from v5.1 to v5.1.2

cd esp_idf
git checkout v5.1.2
cd ..

step4
------
git status

git add .gitmodules
git add esp32_S3/esp_idf

step4
------
git commit -s

step4
------
git push origin main

Next-Time clone in this way
-----------------------------
git clone --recurse-submodules https://github.com/JK1926/Demo.git